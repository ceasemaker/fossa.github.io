<?php
// Silence is golden